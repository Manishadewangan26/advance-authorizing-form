from django.contrib import admin
from user.models import Profile

# Register your models here.
class ProfileAdmin(admin.ModelAdmin):
    list_display=['first_name','last_name','email','username','password1','password2','created_at','updated_at']

admin.site.register(Profile)
